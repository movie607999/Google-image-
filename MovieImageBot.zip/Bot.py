import logging
import requests
from telegram import Update
from telegram.ext import ApplicationBuilder, MessageHandler, filters
from config import BOT_TOKEN, RAPID_API_KEY

# লগ সেটআপ
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

# IMDB থেকে মুভির তথ্য আনার ফাংশন
def fetch_movie_info(movie_name):
    url = "https://imdb8.p.rapidapi.com/title/find"
    querystring = {"q": movie_name}
    headers = {"X-RapidAPI-Key": RAPID_API_KEY, "X-RapidAPI-Host": "imdb8.p.rapidapi.com"}

    response = requests.get(url, headers=headers, params=querystring)

    if response.status_code == 200:
        data = response.json()
        if "results" in data and len(data["results"]) > 0:
            first_result = data["results"][0]
            title = first_result.get("title", "N/A")
            year = first_result.get("year", "N/A")
            image_url = first_result.get("image", {}).get("url", "N/A")
            imdb_id = first_result.get("id", "N/A").replace("/title/", "").strip("/")
            imdb_link = f"https://www.imdb.com/title/{imdb_id}/"

            return f"🎬 *{title}* ({year})\n⭐ [IMDB Link]({imdb_link})", image_url
        else:
            return "❌ মুভি খুঁজে পাওয়া যায়নি!", None
    else:
        return "⚠️ IMDB API Error!", None

# ইউজার যখন মুভির নাম পাঠাবে তখন চলবে
async def movie_search(update: Update, context):
    movie_name = update.message.text
    chat_id = update.message.chat_id

    msg, img_url = fetch_movie_info(movie_name)

    if img_url:
        await context.bot.send_photo(chat_id=chat_id, photo=img_url, caption=msg, parse_mode="Markdown")
    else:
        await update.message.reply_text(msg)

# বট চালু করা
def main():
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, movie_search))

    print("Bot is running...")
    app.run_polling()

if __name__ == "__main__":
    main()
