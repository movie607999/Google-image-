# config.py

BOT_TOKEN = "YOUR_TELEGRAM_BOT_TOKEN"  # তোমার Telegram Bot Token এখানে বসাও
RAPID_API_KEY = "YOUR_RAPID_API_KEY"  # তোমার RapidAPI Key এখানে বসাও
